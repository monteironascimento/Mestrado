#include <stdio.h>
#include <stdlib.h>

typedef struct {
    unsigned int codigo;
    char nome[50];
    int* p_notas;
} Aluno;


void criarAluno(Aluno** aluno, int codigo, char nome[], float** notas){

    

};

void imprimirAluno(Aluno* aluno){
    
   /* printf("\n");
    printf("------- ALUNO --------\n");

    printf("Código: %d\n", aluno->codigo);
    printf("Código: %s\n", aluno->nome);

    for (int i = 0; i < 10; i++)
    {
        printf("Nota (%d): %d\n", (i+1), &aluno->notas[i]);    
    }*/
    
};


    

int main(){

    //Dados    
    int codigo = 10;
    char nome[] = "RODRIGO";
    float* notas = (float*) calloc(3, sizeof(float));
    notas[0] = 10.2;
    notas[1] = 20.5;
    notas[2] = 98.9;

    //Ponteiro de Aluno alocar memoria
    Aluno* pAluno = (Aluno*) calloc(3, 4 + 50 + 12);

    criarAluno(&pAluno, codigo, nome, &notas);
    imprimirAluno(pAluno);
}    