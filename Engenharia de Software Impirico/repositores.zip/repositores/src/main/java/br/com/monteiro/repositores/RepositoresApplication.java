package br.com.monteiro.repositores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepositoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepositoresApplication.class, args);
	}

}
