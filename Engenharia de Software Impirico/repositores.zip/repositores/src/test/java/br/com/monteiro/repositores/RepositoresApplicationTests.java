package br.com.monteiro.repositores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepositoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
